#Cetak judul program ini
print("Buat Email Baru Khusus Anak Pacil")

#Melakukan input untuk info yang akan digunakan dalam pembuatan email
a = input("Nama Depan: ")
b = input("Nama Panggilan: ")
c = input("Tanggal Lahir: ")

#Mencetak ucapan selamat datang sesuai dengan nama yang diinput
print("Halo " + a + ", selamat datang di Fasilkom!")

#Mencetak email baru untuk anak pacil
print("Email kamu adalah " + a + b + c + "@ui.ac.id")