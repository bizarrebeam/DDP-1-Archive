#Cetak judul program ini
print("Yuk kenalkan dirimu dengan Pacilians '23!")
print()

#Input informasi pengguna 
nama_lengkap = input("Nama lengkap kamu?: ")
nama_panggilan = input("Nama panggilan kamu?: ")
sma_asal = input("Kamu dari SMA/K mana nih?: ")
jurusan = input("Kamu dari jurusan apa?: ")
mbti = input("Kasih tau MBTI kamu dong!: ").upper()
funfact = input("Sebutin satu funfact yang jadi ciri khas kamu: ")

#Menampilkan paragraf perkenalan 
print("Halo Pacilians '23!")
print("Perkenalkan, nama aku " + nama_lengkap + ", lebih enak dipanggil " 
      + nama_panggilan + ".")
print("Aku berasal dari " + sma_asal + " dan sekarang menempuh studi di " 
      "jurusan " + jurusan + ".")
print("Dengan MBTI " + mbti + ", funfact aku " + funfact + ", loh!")
print("Semoga kita jadi teman baik ya selama di pacil ini. Salam kenal!")
