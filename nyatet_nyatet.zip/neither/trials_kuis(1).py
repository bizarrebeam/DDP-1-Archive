m = 100
if not m + 100:
    print(1)
else:
    print(0)
if not 0 and 100:
    print(4)
if m > 10 and 0:
    print(2)