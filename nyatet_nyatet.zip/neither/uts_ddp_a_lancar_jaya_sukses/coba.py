x = -15%7
print(x)